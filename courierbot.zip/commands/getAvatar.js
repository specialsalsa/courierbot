const cb = require("../courierbot");

module.exports = {
    name: "getavatar",
    description: "gets the avatar URL of a user",
    async execute(message, args) {
        cb.client.users.fetch(message.member.id).then(thisUser => {
            message.channel.send(thisUser.avatarURL());
        });
    }
};
