class User {
    constructor(id, name)
}